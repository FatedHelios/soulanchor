SOULANCHOR - SINGLE EXE DISTRIBUTION

Extract this developer package into a folder.
Close any running SoulAnchor window, then run Build.bat to rebuild SoulAnchor.exe.
Double-click SoulAnchor.exe to run it.

To distribute: ZIP only SoulAnchor.exe. The recipient extracts and runs it.
The window/taskbar icon and all UI visuals are embedded or drawn by the app.
No Assets folder, source files, BAT files, or PowerShell are needed to run the built EXE.
Windows with .NET Framework 4.5 or newer is required.

Assets/Scroom.ico is needed only when building (the EXE file icon is embedded by the compiler).
Start.bat builds only if the EXE is missing. Use Build.bat to update an existing EXE.
Launch.ps1 remains an optional source launcher.
Ctrl+Shift+F8 pauses inputs.

Preferences save automatically to %APPDATA%\SoulAnchor\settings.ini and survive EXE updates.
Saved: interval, idle requirement/time, debug visibility, enable new instances.
Input starts paused each time. Existing window enable selections are not restored.
The startup info popup can be disabled in Settings; this preference also saves.

Version 1.1.0: Saved minimize-to-tray setting while running; double-click tray icon to restore. Tray menu offers Open, Pause and Exit. Added control tooltips and About/EXE version information.
