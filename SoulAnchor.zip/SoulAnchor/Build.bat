@echo off
setlocal
cd /d "%~dp0"
set "SOUL_CSC=%WINDIR%\Microsoft.NET\Framework64\v4.0.30319\csc.exe"
if not exist "%SOUL_CSC%" set "SOUL_CSC=%WINDIR%\Microsoft.NET\Framework\v4.0.30319\csc.exe"
if not exist "%SOUL_CSC%" (
 echo Windows .NET Framework compiler was not found. Enable .NET Framework 4.x and try again.
 pause
 exit /b 1
)
"%SOUL_CSC%" /nologo /target:winexe /platform:anycpu /optimize+ /out:"SoulAnchor.exe" /win32icon:"Assets\Scroom.ico" /reference:System.dll /reference:System.Core.dll /reference:System.Drawing.dll /reference:System.Windows.Forms.dll "Source\SoulAnchor.cs"
if errorlevel 1 (
 echo SoulAnchor could not be built. The compiler error is shown above.
 pause
 exit /b 1
)
exit /b 0
