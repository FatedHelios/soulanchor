using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

[assembly: System.Reflection.AssemblyVersion("1.1.0.0")]
[assembly: System.Reflection.AssemblyFileVersion("1.1.0.0")]
[assembly: System.Reflection.AssemblyProduct("SoulAnchor")]

namespace SoulAnchor {
    public static class Program {
        [STAThread]
        public static void Main() { Run(); }
        public static void Run() {
            Native.ConfigureDpi();
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            using (var single = new System.Threading.Mutex(false, "Local\\SoulAnchor.Gui")) {
                bool owner = false;
                try { owner = single.WaitOne(0); } catch (System.Threading.AbandonedMutexException) { owner = true; }
                if (!owner) { MessageBox.Show("SoulAnchor is already open."); return; }
                try { Application.Run(new MainForm()); } finally { single.ReleaseMutex(); }
            }
        }
    }
    internal static class Native {
        [DllImport("user32.dll")] public static extern bool SetProcessDPIAware();
        [DllImport("user32.dll")] public static extern IntPtr SetThreadDpiAwarenessContext(IntPtr context);
        public static void ConfigureDpi() {
            // Windows PowerShell owns the process; override the GUI thread as well.
            SetProcessDPIAware();
            try { SetThreadDpiAwarenessContext(new IntPtr(-2)); }
            catch (EntryPointNotFoundException) { }
        }
        public delegate bool EnumProc(IntPtr hwnd, IntPtr data);
        [DllImport("user32.dll")] public static extern bool EnumWindows(EnumProc proc, IntPtr data);
        [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr hwnd);
        [DllImport("user32.dll")] public static extern bool IsWindow(IntPtr hwnd);
        [DllImport("user32.dll")] public static extern bool IsIconic(IntPtr hwnd);
        [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr hwnd, out uint pid);
        [DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern int GetWindowText(IntPtr hwnd, StringBuilder text, int size);
        [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr hwnd);
        [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
        [DllImport("user32.dll")] public static extern bool ShowWindowAsync(IntPtr hwnd, int cmd);
        [DllImport("user32.dll")] public static extern bool GetLastInputInfo(ref LastInput info);
        [DllImport("user32.dll", SetLastError=true)] public static extern uint SendInput(uint count, Input[] inputs, int size);
        [DllImport("user32.dll")] public static extern short GetAsyncKeyState(int key);
        [DllImport("user32.dll")] public static extern uint MapVirtualKey(uint code, uint mapType);
        [DllImport("user32.dll")] public static extern bool RegisterHotKey(IntPtr hwnd, int id, uint mods, uint key);
        [DllImport("user32.dll")] public static extern bool UnregisterHotKey(IntPtr hwnd, int id);
        [StructLayout(LayoutKind.Sequential)] public struct LastInput { public uint size, time; }
        [StructLayout(LayoutKind.Sequential)] public struct Input { public uint type; public InputUnion data; }
        [StructLayout(LayoutKind.Explicit)] public struct InputUnion {
            [FieldOffset(0)] public Keyboard keyboard;
            [FieldOffset(0)] public Mouse mouse;
        }
        [StructLayout(LayoutKind.Sequential)] public struct Keyboard { public ushort key, scan; public uint flags, time; public UIntPtr extra; }
        [StructLayout(LayoutKind.Sequential)] public struct Mouse { public int x, y; public uint data, flags, time; public UIntPtr extra; }
        public static double IdleSeconds() {
            var li = new LastInput { size = (uint)Marshal.SizeOf(typeof(LastInput)) };
            if (!GetLastInputInfo(ref li)) return 0;
            return unchecked((uint)Environment.TickCount - li.time) / 1000.0;
        }
        public static bool ModifiersHeld() {
            return new int[] { 16, 17, 18, 32, 91, 92 }.Any(k => (GetAsyncKeyState(k) & 0x8000) != 0);
        }
        public static bool Space(bool release) {
            ushort scan = (ushort)MapVirtualKey(32, 0);
            if (scan == 0) return false;
            var input = new Input { type = 1, data = new InputUnion { keyboard = new Keyboard { key = 0, scan = scan, flags = 8u | (release ? 2u : 0u) } } };
            return SendInput(1, new Input[] { input }, Marshal.SizeOf(typeof(Input))) == 1;
        }
    }
    internal class Instance {
        public IntPtr Hwnd;
        public int Pid;
        public string Identity, Title;
        public bool Enabled;
        public DateTime Due = DateTime.UtcNow;
        public string Status = "Disabled", Last = "Never";
        public DataGridViewRow Row;
    }
    internal class DiamondLogo : Control {
        readonly Timer animation = new Timer();
        readonly Stopwatch clock = Stopwatch.StartNew();
        public DiamondLogo() {
            SetStyle(ControlStyles.UserPaint | ControlStyles.SupportsTransparentBackColor | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, true);
            BackColor=Color.Transparent;
            animation.Interval=33; animation.Tick += delegate { if (Visible) Invalidate(); }; animation.Start();
        }
        protected override void OnPaint(PaintEventArgs e) {
            base.OnPaint(e);
            e.Graphics.SmoothingMode=System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
            e.Graphics.TranslateTransform(Width/2F,Height/2F);
            e.Graphics.RotateTransform((float)(clock.Elapsed.TotalSeconds*45 % 360));
            float r=Math.Min(Width,Height)*0.32F;
            var diamond=new PointF[] { new PointF(0,-r),new PointF(r,0),new PointF(0,r),new PointF(-r,0) };
            using (var fill=new SolidBrush(Color.FromArgb(71,54,31))) e.Graphics.FillPolygon(fill,diamond);
            using (var edge=new Pen(Color.FromArgb(244,209,155),2F)) e.Graphics.DrawPolygon(edge,diamond);
        }
        protected override void Dispose(bool disposing) { if (disposing) { animation.Stop(); animation.Dispose(); clock.Stop(); } base.Dispose(disposing); }
    }
    internal class RoguePanel : Panel {
        readonly Bitmap texture = new Bitmap(128, 128);
        public RoguePanel() {
            DoubleBuffered = true; BackColor = Color.FromArgb(42, 35, 24);
            var random = new Random(42);
            for (int y = 0; y < 128; y++) for (int x = 0; x < 128; x++) {
                int n = random.Next(-10, 11);
                texture.SetPixel(x, y, Color.FromArgb(48+n, 40+n, 27+n));
            }
        }
        protected override void OnPaintBackground(PaintEventArgs e) {
            using (var brush = new TextureBrush(texture)) e.Graphics.FillRectangle(brush, ClientRectangle);
            using (var wash = new SolidBrush(Color.FromArgb(100, BackColor))) e.Graphics.FillRectangle(wash, ClientRectangle);
        }
        protected override void OnPaint(PaintEventArgs e) {
            base.OnPaint(e);
            using (var dark = new Pen(Color.FromArgb(20, 16, 11), 2))
            using (var bronze = new Pen(Color.FromArgb(178, 128, 73), 2))
            using (var light = new Pen(Color.FromArgb(244, 209, 155), 1)) {
                e.Graphics.DrawRectangle(dark, 1, 1, Width-3, Height-3);
                e.Graphics.DrawRectangle(bronze, 4, 4, Width-9, Height-9);
                e.Graphics.DrawRectangle(light, 7, 7, Width-15, Height-15);
                foreach (int x in new int[] { 4, Width-16 }) foreach (int y in new int[] { 4, Height-16 })
                    e.Graphics.DrawRectangle(bronze, x, y, 10, 10);
            }
        }
        protected override void Dispose(bool disposing) { if (disposing) texture.Dispose(); base.Dispose(disposing); }
    }
    internal class RogueButton : Button {
        bool hover, pressed;
        public RogueButton() { SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, true); }
        protected override void OnMouseEnter(EventArgs e) { hover=true; Invalidate(); base.OnMouseEnter(e); }
        protected override void OnMouseLeave(EventArgs e) { hover=false; pressed=false; Invalidate(); base.OnMouseLeave(e); }
        protected override void OnMouseDown(MouseEventArgs e) { pressed=true; Invalidate(); base.OnMouseDown(e); }
        protected override void OnMouseUp(MouseEventArgs e) { pressed=false; Invalidate(); base.OnMouseUp(e); }
        protected override void OnPaint(PaintEventArgs e) {
            Color fill = pressed ? Color.FromArgb(202,167,119) : hover ? Color.FromArgb(255,231,195) : BackColor;
            using (var brush = new System.Drawing.Drawing2D.LinearGradientBrush(ClientRectangle, fill, Color.FromArgb(226,192,143), 90F)) e.Graphics.FillRectangle(brush, ClientRectangle);
            Point[] edge = new Point[] { new Point(5,1), new Point(Width-6,1), new Point(Width-6,4), new Point(Width-2,4), new Point(Width-2,Height-5), new Point(Width-6,Height-5), new Point(Width-6,Height-2), new Point(5,Height-2), new Point(5,Height-5), new Point(1,Height-5), new Point(1,4), new Point(5,4) };
            using (var pen = new Pen(Color.FromArgb(87,61,34), 2)) e.Graphics.DrawPolygon(pen, edge);
            using (var pen = new Pen(Color.FromArgb(179,128,73), 2)) e.Graphics.DrawRectangle(pen, 6,5,Width-13,Height-11);
            using (var pen = new Pen(Color.FromArgb(255,235,198))) e.Graphics.DrawRectangle(pen, 8,7,Width-17,Height-15);
            TextRenderer.DrawText(e.Graphics, Text, Font, ClientRectangle, Enabled ? ForeColor : Color.Gray, TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
            if (Focused) ControlPaint.DrawFocusRectangle(e.Graphics, new Rectangle(10,10,Width-20,Height-20));
        }
    }
    public class MainForm : Form {
        readonly Dictionary<string, Instance> instances = new Dictionary<string, Instance>();
        readonly DataGridView grid = new DataGridView();
        readonly Label summary = new Label();
        readonly TableLayoutPanel layout = new TableLayoutPanel();
        bool waitForIdle = true, showDebug = true, showStartupInfo = true;
        int idleSeconds = 10;
        const string AppVersion = "1.1.0";
        bool minimizeToTray;
        readonly NotifyIcon tray = new NotifyIcon();
        readonly ContextMenuStrip trayMenu = new ContextMenuStrip();
        readonly ToolTip tips = new ToolTip { AutoPopDelay = 9000, InitialDelay = 450, ReshowDelay = 150 };
        bool loadingSettings = true;
        readonly string settingsPath = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "SoulAnchor", "settings.ini");
        readonly Button start = new RogueButton();
        readonly NumericUpDown minutes = new NumericUpDown();
        readonly CheckBox auto = new CheckBox();
        readonly TextBox log = new TextBox();
        readonly Timer timer = new Timer();
        bool running, busy, closing;
        int ticks;
        float uiScale = 1F;
        int S(int value) { return (int)Math.Round(value * uiScale); }
        Font UiFont(float points, FontStyle style) { return new Font("Georgia", points * 96F / 72F * uiScale, style, GraphicsUnit.Pixel); }
        static readonly Color Bg = Color.FromArgb(38, 31, 22), Panel = Color.FromArgb(47, 38, 26), TextColor = Color.FromArgb(231, 223, 207), Accent = Color.FromArgb(211, 178, 123);
        public MainForm() {
            AutoScaleMode = AutoScaleMode.None;
            using (var g = Graphics.FromHwnd(IntPtr.Zero)) uiScale = Math.Min(g.DpiX / 96F, Math.Min(Screen.PrimaryScreen.WorkingArea.Width / 1000F, Screen.PrimaryScreen.WorkingArea.Height / 780F));
            uiScale = Math.Max(0.75F, uiScale);
            Text = "SoulAnchor"; ClientSize = new Size(S(1120), S(740)); MinimumSize = new Size(S(960), S(650));
            FormBorderStyle = FormBorderStyle.None;
            using (var iconStream=new System.IO.MemoryStream(Convert.FromBase64String("AAABAAUAEBAAAAAAIAA9AwAAVgAAABgYAAAAACAAZgUAAJMDAAAgIAAAAAAgANUHAAD5CAAAMDAAAAAAIABoDAAAzhAAAEBAAAAAACAAnAIAADYdAACJUE5HDQoaCgAAAA1JSERSAAAAEAAAABAIBgAAAB/z/2EAAAMESURBVHicfZNPaBR3FMe/7/ebbXZ2TWbixsgmhiQmGhqtSlcbgoqCSgOhKuoUlILgsYfSijel40jpRSg9FW2h0JPFLVQFieDBaNCwtBtTEQ+1aSio2biru52dptmdmd/z4GxQKX2n7+/wvr/35/OA/wjLgqRIEwAigmVZMnr+b5BtQ0Rah2GYAEwARsPMAuRrCa9qAjGDsaq77fCWtuVfaoCBWAxvJXT1R/H5hdzsn2fgoWgDwgHUq0bCtm0BILVloOvC6dFhvnRgO2d3beLc2eNcnh3na+dsHl3f/bhnfd+HUc5SJcRRq6Pvrrkz8Z3DlYfX/V+//yL8Yfugyp2zVfHJpJq/f9W/cng3H9/cz739nYcas9IsC4KywFBf+psjm9cNZ/aO+K4fxIzebsRNA7NXxlCvVODNzWuLbjU8evQQLV66/u3FYnlmMLvwGwFAomfFxiMd7dMH06kw8V5GJkwDjycmUStXQEIgrNUR+nUMHvsIA3tHgruXx7SPna9/vjdTOKABQJeufzAQjwWeW+W5y2NCACSbmkDayzaFlAj9EO6jJ1z665FoevY8XJ2ID81sWN2uAUDgLjSn9u3UduwZhvdvDURA4AfRaghKKUghIGMaxf4uUCIhIEk06V7N0GzbFo7jnMw/LQ+p6d83/LOwCMXKbDUNqvs+VKig63G4VQ9BPajq8ZhffFZxbz8tWaWC+5AiFhiAiIAxD45sndq//32zpXkZJ5M6FQpFNXX3vvjq/MV9ACYA+AA8ACSiZCIiJaUsZzKZ+XR6hRq/lUPg17GqcyWuXruBZFJHR3O8JIQoS0le9CE3sGVmFkEQUD6fb2NmeeLTY9zX34O67+P0qU+QWm5yjaldqZC2bWMNEYkNA1gWiEiwBN5eu6bH6OpKB61GizJamsOOjvb6O+vWUspIbn3J3Y4lhLWGyGahbPtz4ThOfmr6wWTvjTvDgR+CmaHrcTl+K1esegs/Akw3b9LSHbx5no2Bpvo7Wz8jKSUrZkkk5+ZKP7kBfomqXjJ4AfImOrOqzLrJAAAAAElFTkSuQmCCiVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAFLUlEQVR4nJVVW2xUVRRd+9zHzO10Oh36GGyB6QsURgkRwUfAARRBHiGCY4ISQWNiQD41gR+BRBMTDTFi+NAElAAxmWACicGoEQdUQqBpgVIBeRSptB2o7XQenbn3nrP9GFoKoTx2cn/uvnets/Ze+2zCgwWN8p4f8P97hhgtEYtBuwc5cL9kNBrVE4mEG4tBS54P+zNpjREEgsEgSibUqgM7DqSL30FPJOA+DIFAUT5PnFI/0wfebhA1KmYGQMouwLUdNy3VrhnPvbAxHo/bADQACneU7W4EAoASRKhvGLu51vJ8uDgUpArTgCMlTF8Jxs+fA1VwcPTSP9h38Lc25fV80t52ec8IzGESfSRyDNDigGya1jTFTGe/mTUuNGNeVTmXKKkcxyWpXJTXjMX0RS+CiDAjl5MVnZ2P7794dbeaEl5m6oG3Tp06lR1JMlKBxoCaPPWxiZWDqcOr5j4TWrF2jVPQNKO/4yravvoW7uAg6pcsQNOKpcglr8OqqkTvkaOqZededQaa/ktP36E6ZS1MVrWrRAISAA85hGKxGIiIVbpv25rozNCqD9bZgx6PwUSomDwJgfowhBBIHm9B569HYAWDyFzpRGdrmxC6rs/1W/bsCv/co3b/xkQCbjQKbbhEmzaBtmyJy0ikbs9Cv/elScGAO6Cbpq5sQAiwkjDL/AADhf4BnN31HfrOXUD2WjcGLnXAKCtDaNVr5upUyunc+vXm1kj4eiJxZXsM0CgWi2nxeFxGHg3PGWPph96tqXC9hq5PfP1VGD4fjBIL5777HgMdV6F5zKJcIrj5PAgEb2UFpr73NqzqSpiu5P1f7sDWn37PVJb5GhLN53v1ZDJJAJBn9WSd5VF+00BeMdp37i26wPJC5gvQLS/AtxxolJSAXQl2XWimAUgFZXlp+vznuTpxzN9l5ycAuCGqEwmORqO6IbC8yWOQyubIzgyCXQV2FexUBsqRcDJZONnc8GOnM3ALBaQ7r6H39FnY6Sz6Ll1Bd3y/W2d5pLQRAwA9DqjZmZ6x5MipdrAMTUujlMk7LIiKFqN7TzsYYBS4t60VLAjBhhpUdPyrGQJPEwA9Boh489mumurA8m6P9+fGec9SNpeHEEVcpRhKKYBu9zRzsReaJsCKSUkJX1kpjjOMxO6Df2lV1W8yUEQZavSCWU98Fq4NvWM7riRAk6w8hqZ7TY95W/1vdhpSSuTzBaUJkQaRMnUNN1Lpy/sOH1uMHLoxRHDHiAcAGAAcv0Eb3li5ZMP6taudvv4BQ4ih0zNKfT7VcrJdbPnoiwsd3f1PjcBIA5AYunJuU81MRJRi5l4iSgUCVm5cTQg//HgIn2/biUdCVWhqmIDjJ05jy8fbECjzIeAvlUKIFBGliKifiORNIjU8aLdUEwOgSCRiMLPjukoopdDXl0Ly+n+wHQce10RqII2enhtwHBeKmaSURHSbF+5+2Q0lLctiAKzrOtKZLNavW43Y8pcBAJlsDq8sm4+VsSVoP/s3pHIhhBh1s911WzU3N7tEhNLSkkXTpkWgCaH5fNZw/b0eDzRdiKbGOlk3vjZcG/TPBIY33P0JhiQKIcJVlWMUK4aU8laSGbbtorzcr3w+ywN2xzyUAgCCmWE79q4//jwhFFjpuq6EEEoIoQBwaWmJ29J6xrja2XNG09EKgOLxYmNHxqhTOrR8ptSHPm1smPA+EYGL0wVWDNPQ0dWdPH3y5MUFOaDr5mEfnGBEnsMVvrlKu2UIklCaBmFoZS3nu7pujAYOAP8DdWZVk8p1YxYAAAAASUVORK5CYIKJUE5HDQoaCgAAAA1JSERSAAAAIAAAACAIBgAAAHN6evQAAAecSURBVHicxZdbbFzVFYa/vfc5c+Y+tpO4BEJCQnOzAwkMgXARBtILmCQQ1EkrxKVIqCq0VV9KVVrRCPEQqAqlQg0UCkSV+pAO90sekKi4tFBBB4ghY5KQECji5nicsceeOZe9dx9mbGxMiJu26pJmdHRm7f//1zr7/GsP/J9D/A/W2aPE/I+JAejp6XFmkjdjwPEoFFDFIloAPzz99OyoU7V+pJvrOzoAyNVrZuvz5RpAAVQR9H9DwHiOLXR1dfTb2jYrRI8xxgiQCIEJIpAgpPRj2K2/2H3WLZso6slrj0rA5KrXnLxwXSU021ZmErPmx10CA1IKdMMnc8Lx6HqDRq3GrnrIJ8O1ZzKuuP3lnQeesZNw/l0BCtBXrl496x8jnzyYVmL9Wbk0Z+ZSOuM5Uo/XZCwnXfddcosWENZ9an4Q3XzjFnfnxwdRQj4538SveezttwfH8T5PIr+M/IwVi3pfrX68Z2nKW3/louPsRfM6rUrEVTXUYlRrUQsjMSaE4CudYtQK4TuOyM7tdH+88Rv60kzcJjx3/T5R37Nq+YLeFrk6YgcKhYLqKhbto90Le+NWP7Yml1bfv+G6aPaSRU6tEUAY8Mad9xLWRtF+QOdpK1lx7RUEtTGklCAFOgh46467GRw4GL1eD52XDtV0PYgu3fj2+zvKhYIoFosTnfh8B2SxWNSlfD6OMds3zp2tfvLzH+iOU052GlYQ8zzSxx7D7JXdhGNjyJhDODbG0J79xNvbQIB0HKRSiPY2Ygjnmx0ZvT6XVCi1vZSfG2+Ryy8SICgUxOaeHmefP7h9ibTxiy7r1d4pq5Q/VEUC1hi0HzBn1QqcZALhOFR27abvd/fzziNPIl2XSv8eXr7pVob3HcBYy7BS6pz8SXqZIr6v7m3f3INDoSDGu+9MFiCKRf3wsvlPrGxPr7ssHdef7n9XzRkZwYnHsMYilQIhiBo+QkgwGjeVxFrLvkefZvjA+9Q++BDtN0BKnLjH8ssLdJ6yQl0bBPr3f3t93cODJzzC88UNreLteAcUYM5csaBXKbn+BFeFiYSnBvfsp1EZQjcamDAAKXjr3j/St/UBrDUgJNYYsBavvY1K/x50EADQsWwJZ95yI7O6lhBGmqUbLlSLkl4ojV1/7qpFvYABlAPQ1dWlyuWybhixOuUquyyZsA1rUULw+m/uwWqDm0riteeo7No9UTX2M3+xWuN4HiiJDsbILpyP15alUamCECSXLmbTDdfbv/7ydjsS6tOBHV1dXUoClMvl6Hv5vOsbc8bxniuyMUdZIYGm0ZgoxB86RPWdd4llMyAEQsppH4QAa3FTST566RX8Q8O4qQQqHkNrQ/2NN9XxMUeEiDM29/Q45XI5Gh8c5iO/Msdg187zHESjIRuhRolJb6lofkV+gEBgD+euAtAWE2nGBgZx4h7SdRnYtZuDL/5dzk0l6Bs9tLYv+GcH8KmTz+edUqkUDghxlec4sUCIcN4Fa9yGkEc9q8GCEFTe6pu4o6OItu7F4ti+vX4u4XkfjIRXArc7pVIpAmQY415q4bm7GlFv59fPjhJxT0XaMKkJAiFmJMoCWIs11oLFGoPXluWdJ/4S7XzhNS+wcoebdO8DpNPKF6XS/irw7XPySwYqn1SSiUQMo23zsbZgjbHNzXeEUFKCaCkGtDHkgpAXPzroPjdw6Ok7f/u1SzZtak7LiYIKhYIqFotmdffCi1Mp70FjrGNt06gEVhhIx1xXKKXQWiOlbFpvS57WBgApJb7vYy0+4IMVILRypAzC6PnjXtu7sfjZeDaH62iaSS65ZuXizMDgYP8V39mQuebqgg2CQPh+iO8HzRKEIJ1K4ijFpwcr4U9v3OIerFS39O//+NZsNusMDw+HNLfncAtSjCufNg03N+/VWsnDwPA1l54/JBG2vS3Hgfc+5P5tD3HgvQ/onNNBNpshmYjz+FPP8vhTz5KMx4m5Lq7j1IHharU6BIx8ETlMtWIAbm46lJicXCrvd7XRxGIur5be5La7/kQ87pE/dQW10Tq+7/OHB/6MUoqz1pza7IoxEhDd3d0uELbwLJ87HU0TMClx4toPQiGEwFpLLptmwTHtZLNpjDEIIZBSMu+4Y1BKIaWklSsBm0gkppHORMCU2HbT5aNfveRNO1gZ4uqrCqxauYxkIs7oaB0hwPNi/Pq2n+EqhTaGsXoDqdzRmWAf7kQ05ffTrt5yfntbJt61fLHGWnLZDK7rTnkl06kkXtwjnU7J5UtPxA/9C3504YVeqVT60pPxlwrI5/MSIAij83LZtNe1fInxG77Q2kzzA60NQRCQTCbk0qUnYqLoPD8TxZm6p6bFjB7BhFoprTEGYzTWTsf8zAsw9sjdPbKAUqlkABFznecOVWs37OwrO2vPP9s0Gg0h5MShBgBrLUpK/CCI+vv3uY5SO7wRp0FTiDkcx0ysXQF68fzZF89qzz2xYd1aKYVsTcPJAgye59Hfv5fnXnxlx9477tkgNm0aJz66Pybjkc/n3VKpFK5avKC37o8+YKxVgMQyeVRpIYR0lHph1213fWsm5DMW0AoJmOuvL6SjCOV5sanAlUGSqYz41X0PVVsbdIrjHS7+BXR8Wwiyokd6AAAAAElFTkSuQmCCiVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAAML0lEQVR4nO1ae4xU13n/feece+/M7M7Ovo1h8e7CwprBC9TDy0TNoMqy46h+1NJgN3WVdlNw0tqpJVxXpVLJpo2lpm2cKlUsg+0mVoiDt0njuJVJ1cYdF6PaeIxMYY0DXR5dWMCGfc3MnXvvefSPOyzDsg92wVX/8CeNVjt77nd+v/N95/d995wFPrVP7VO7UcZmMziTAZ/tM5MZXa+DTAa8vz/FcrlcsH59S9QZ5MZTalq/Ducme/JkqQKDmev810tgfPLVybYtNmffDrRWAPhVAxmD0QYEAwOUHNvOXPSKB/r6Bi6mUikrl8sFcwUw1+cIgE4l29fGLH5/QcltvtKTuDQAY1BuCUwIgBFggGrHgtH6HeWwu3K5/pEKv7OKxqwJJJNJu6+vzwdg3bG8fZVk2OMZ1LdaQt7dlBAlpUEVXhnn8EbHsCRzH87sfRsyX4BiDK+eHQo8wIJSR7jRb/iO92QuN1hMpVLWokU53dsLdcMJpNNpkc1mZTLZUl8r7D2u1KtiglkLbOHfd1OdHeccGuayUyIYpSFiUfzKE4/CqauFKvlQWsOpS+CV519W3/r7V3hVUwOqjHFLSj/xXt+JHRXYZozGrCOwdnnrNjB+f0mbtZZWurulkdqjERqREiACVSw/cY7S0DBuffhBtN97N0oXh0BCAMZAODb846fww2d26IPnL9B/uQHFOMFi/OlSoF7N9R1/pyLaU9q1yBil02kBAOuXt+6AbX3D9YO19zTEzWNLFrKF8WoaIQbh2BCWBSIa3yBEBDIGMl8AtA6/M2GEZNFFJNmJz3R1soebE7Q6EYOvtPSN3kYcr2+4bdHqvr4+P5WCNS24awDPs9msXN/V/pzmfEuNlO66hoT9Bz1PcmpqRKnkgxkNp64WR3f/I/r/+V8QbWqEKUdES4nOh34D8391PYJCEcQurxkRUBor4p0/exqWbSOvNF7/aNg/7Ut7TGo3zmj93kPHD2KadJo2ApkMWDabNeuWt71QItpyK4N8omNBdPPXtnIsbIHUGnbUAY84MFqj6fYVqG6ZD+37IM4giy7qly1F+wP3QLpl2Tdm/KfRQLQugZY70/A9HzEh8DsLmuwvzGtQEc4iJSC7pqvts+l0mmcymaukeSYCrLcXqruzM+YC3UnbUg+3zxcdj2+Gc0sLVD4PIoLRGgAQFApoWJFEtLEBquQBALjjIH/qNN56qgf5gTNwahMAYzBKgRgDCYYgX0Dx7LmwThiNIa0x32L8i/PqfM55LRnzYDablf39/c5sCDAAen2ypf6w7f9CE3kd3NDSL/4maha1IRgrgPiVC0KcQ+YLiDU3gllWmPOMEBSLGD56HId2vIRz+w9AuS5ENAoeieDo7p/irW1/jguHPgSzrJCU50FVV2FeVcSp00p6oC+vS7ZtzuVyxXQaYkYC27eDpVIpvnJla63h4vWSxuoHmxJiVTzGgmgEVF69iUYgaKWw7LcfglUdg5ZhqhBjsONVUEGAA888i4Pf/R5UEODIrl4MvLEX3LIhIjaIAOX5YLaFlY9vxuJND+C3GuPiZttyPEY71t7W2p3NQk5Mpck2MQEwq5e3HdCMrbqnrlptqI/z4ZKH2raF6Hr0d0GchTkMgIiBCCAR+j36yqsY3Lcf3LZgzJX7jgkBP19A9fybUDz38fgYoxQAgohFsOIr3Yi3LQS4wNl/y+LQD3rNy4XAP1/yHVLykf19p3ZVth4TQ1IG37JGMFr1sRfIBluIQBswxpAfOAOrugoiYkMrE6ZIoQgRjWDgjb04+sqrAAyY4FeBBwAtJaxYFMXzH1cQJIAISzc9gJs3rIGWCkG+CBGxUXXrEtQn4qQ/PsMk49ph7PNrOzpeU4B7CesVuZBOpzkARuAvBAZ6WXWE6iyBwBgQEZgQOP7aHhz7yT+h/2ev48iuf0Bx8CwG9+3HB9//EYhRWKhoanU2WoNbIXhiBOW6qFu6GAvv2ghZ8mCUAhMcygsQv6kZy/7wy0g11VrkeYpb1hcCS6/J5XJBppz+V20KAJoRnc8r3dURi6ibHQsXAglBBC0V+n+2J5ycCMoPcOHgYQTFIkQsWm7UZu7FrogOY1B+gCBfCImXyZPgkMUi4ksWoftPn8Cer24nKZUWxC9U+qqMADU3N5tUctEtmtBUxZmp4oxKWl8xyE7UwKlNwE7UINbcCG94BEbqUJVm2dUbbSBiUVz84EOc+vkv4MSry/sBoYoJgcKZQfT9+DXcxBlpENPMX78dYMnybOPYOjo67N7eXsVJ/b4mvuIWx/I/UxdnrgY4Y2FbQARoPf4xSoXyx9nl1mG2H0Zh0LQBCQHifFyiow11OPN2DoWDh/HrC5t5SUoIsGf/vbXV7gE0UJFCtm2HO4rINcYYCUOuH0D5Acx1v7dNbcQ5lOcjKLrwR0bhj44BxMAdC+fefR+n/vVNROoSGCsFCIyBgckPlUrjUkoAkAF4L6BSy1s3Opb1xljJ95dEHfvxrsUoVMfAtL4BL59TUgCMKa88u5yGRNBBAK0U5NAIzg7nsfvcsBrTGmTMwf2HT9yeTqeFAIAkYDKZDO8/nOtXSr0bi9qrB4ZG1dCyxXzjQ59DfmgUjE/aitw4C1e34vfwO6umGgf/9iUkhkdRZwsaKfnMgtkJABs3btQCAHoAjd5eBuBUMtlydz3nPz+jVNehCyP02dE8KwyPQYhPmABwlfwaraG0hhtI8+LABXWOcxHVZsvbfSd3bgdYT0+PrpRRDYD19Q1c/Ms/uu/Xnv/RvtGGeJVqaK4HiEFY/wcEJpiSGvW1cfMXQ2P+6UA6jbbz6JuHju5Mt7ZGesqnGhPrgM5kwJ9a80jxhd3/+eKBw8e6v7Pjx3BLHtgkxelSwI0xk1bemWxc2TD5FtPGIOLYNHh+yDGB/6U33z/zYvm1tjTuYzK/ADgRyc625ueUVI9ooxUMXdV2EFHEALAsAUY0qzJAAJRSkEqDAG2M8a4eZRQjJriwvnrkxODOVApWLodgop+p/IOIzFu7/zrqFUbNRxdHrxj7Xu6Xkf/44JenR0bz0W98fSu6buvE2FgBjIXNHWfsKkJaaZgy8KbGery066dq1w9/wusb6vY99vA9dx4/OyLa5yXkpfFN9TXmo6pR2rTpGTcNiCwgJ7ictJUAwuwgYww2bNrqTjYgmUyqaq4gpQIRQyTiwHFsMMYgpUKx6Fa84Iclpro2BgIhkBLCCqeWUiEIpNq09RkXxhCIJgskmwz8dAQuzTql1YyOcl1nQxsN27bw3/2n8M2/eR6WLdDRfgse+8ojGMsXwXlYxX3fx9ef/juUSj6E4Pirp5+qnIQAIL1xI58CqJ4Kx3QErtmEYCgUinj3vUOwHQtGGQhx2TURwRiD9w8eQbFYgl1upadpWq997ut3ETagjDHEYhHYtgXHsSdVpWg0AmMA2572pGRWdkMIAOEq27YF27auWP1Ksy0L0lawrf8HBJwaj7uwwRmH63rouq0TL3//W2CMgTHCWL4AzsNmV+twn3z3O18DTKhCVplEub4Q5nhXMOcLhmzfR3lGZEolD0EQgPNQiSIRZxzcRIs44d8d2wYxgut6CAIJRuRjmo16QwlcOhW4Y9WSZ8fG8pH77r1Td3V1olBwYYyB1nrKqqy1hi4ft4yM5HH/vXey5PKlQdF1U2tXdHRns1mVSqVmlV+zJnD+/HkCAAOsk1KylgU3m9pEDaSUVxzsTmdEhCAIsGDBPKqtrTFGmxpmzBIAxnXdWWnTnFOIYEaICJ7nzQr8+POXng0kABhjqDgXHNdxyUY1WhsZcZxxnb/mJylMJ8uyICxhwppgYnNBMWsVam5uvnQ6uz8asW//n4HBwGjDOefltmKGSFDYE0WjEQwPj5rhiyMQQpAmOgqAotHoJ3vFBITHjz090OtWLn5hbDTf/bm70vLJrZuFVjMLiTFhlR4eHsEfb/umPnHiFIvHa7701oEPX9y+fTvr6emZlRrN+ZKvo6PDPnbsmLdhVcdzxaK7ZdmtS1zOOTczNdXGgFscQxeH2cmTp0V1IrF5X+7I8+k0RDY7ecP2SRAAKi4/7li5aKfnBb+nJlzwTWVhFDiiVZFH9757dEe6tTVScW88OxBzeWgyW7ti8Z8wmBk13BA0J8GUCfrffv/4Dy5dHN4oHHO1uarZdf+rwf8CCNF4a2asKAYAAAAASUVORK5CYIKJUE5HDQoaCgAAAA1JSERSAAAAQAAAAEAIBgAAAKppcd4AAAJjSURBVHic7Zu9SgNBEMdH8SEsY20bsMhL2GmhYCl2CkJASBEQAoK2loIWvoiFYGutpW8RizBhs9mPmd2Z3Vxuf5XGu739/+dj9zYI0Gg0Go1Go6/slHjI8HAwT7336/tXdY7qBuSIN9EyQs0AKeEmGiaoGGCLvz3YJ903mk3gYzxd+ezh52/tOkkjRA1wRZ0qHmBhgI/jk6u1zySM2M0dAHFFXUo8jhd7ZgrZDuZGHYkZAADL8pAsi6wMyI16KpLZkJwBLvGhKNrNzYaSAa5x7GzgZsIe52LEFI/RoApwkXMvPh+NGB4O5hwT2CWQKj5HJGUcsyw45ZDcAyQij3yMp9ESMa+NzYkDywDbWamoIiFxHJMA6FlANsCV+lyoS50tlCIcx+aWAskACfFcUDRHfIoJ0W4ZE88pA04KU3E937Vh8q0MScsgl1LCUwiWgMReu4Z41999WsgZ4Kt9n0DXq21JRrMJwHjqfG8wEXsbtKkpHqGUiZoBmkhsmhCvATWWPklQfGxJ7GQGSLKVBnD6j3NzkHqouamEzgzIy+DR3aXglMrwef8MAIsA+pZDZwnY28bYWrrphLbE3h6g/ZVUKWLvA8Em2HUTKC9DW7kK2IQCSYqwxvd8pYhlMSkDuloKlHmLCzOz5e3lUWzcs4ub5c+SAelFDwjRewOKHImdnl+v/P7++iRyrQS9z4BmQO0J1Kb3BhRpgpxGpt30bHqfAc0AycG0tsH2eJIvZy0Dak+gNs2A2hOoTTNAcjDzoMI8wJCgMwciGiZoiQdo/zCh1wOkJ6t1MKvaBKUm3dVT6UYX+AdSmg/WJugj6QAAAABJRU5ErkJggg==")))
            using (var embeddedIcon=new Icon(iconStream)) Icon=(Icon)embeddedIcon.Clone();
            BackColor = Bg; ForeColor = TextColor; Font = UiFont(10, FontStyle.Regular); StartPosition = FormStartPosition.CenterScreen;
            var shell = new RoguePanel { Dock = DockStyle.Fill, Padding = new Padding(S(12)) }; Controls.Add(shell);
            var header = new RoguePanel { Dock = DockStyle.Top, Height = S(86) };
            var body = new Panel { Dock = DockStyle.Fill, BackColor = Bg }; shell.Controls.Add(body); shell.Controls.Add(header);
            var title = new Label { Text = "SOULANCHOR", Font = UiFont(27, FontStyle.Bold), AutoSize = true, Location = new Point(S(76), S(23)), BackColor = Color.Transparent };
            var diamondLogo=new DiamondLogo { Location=new Point(S(18),S(17)), Size=new Size(S(52),S(52)) }; header.Controls.Add(diamondLogo);
            header.Controls.Add(title);
            header.Controls.Add(new Label { Text = "|  Rogue Lineage Anti-AFK", Font = UiFont(12, FontStyle.Regular), AutoSize = true, Location = new Point(S(440), S(34)), BackColor = Color.Transparent });
            var close = MakeButton("\u00d7", delegate { Close(); }); close.AutoSize=false; close.Size=new Size(S(38), S(38)); close.Location=new Point(ClientSize.Width-S(76), S(22)); close.Anchor=AnchorStyles.Top|AnchorStyles.Right; header.Controls.Add(close);
            var minimize = MakeButton("\u2014", delegate { if (minimizeToTray && running) HideToTray(); else WindowState=FormWindowState.Minimized; }); minimize.AutoSize=false; minimize.Size=new Size(S(38),S(38)); minimize.Location=new Point(ClientSize.Width-S(124),S(22)); minimize.Anchor=AnchorStyles.Top|AnchorStyles.Right; header.Controls.Add(minimize);
            Point drag = Point.Empty;
            MouseEventHandler beginDrag = delegate(object sender, MouseEventArgs e) { if (e.Button==MouseButtons.Left) drag=e.Location; };
            MouseEventHandler moveDrag = delegate(object sender, MouseEventArgs e) { if (e.Button==MouseButtons.Left) { Left += e.X-drag.X; Top += e.Y-drag.Y; } };
            header.MouseDown += beginDrag; header.MouseMove += moveDrag; title.MouseDown += beginDrag; title.MouseMove += moveDrag;
            var sidebar = new RoguePanel { Dock=DockStyle.Left, Width=S(215), BackColor=Color.FromArgb(94,94,51), Padding=new Padding(S(18),S(32),S(18),S(18)) };
            body.Controls.Add(sidebar);
            var nav = new FlowLayoutPanel { Dock=DockStyle.Fill, FlowDirection=FlowDirection.TopDown, WrapContents=false, BackColor=Color.Transparent };
            sidebar.Controls.Add(nav);
            foreach (string item in new string[] { "INSTANCES", "SETTINGS", "ABOUT" }) {
                string name=item;
                var button=MakeButton(item, delegate { if (name=="SETTINGS") ShowSettings(); else if (name=="ABOUT") MessageBox.Show(this,"SoulAnchor v" + AppVersion + "\r\nRogue Lineage instance manager\r\nCreated by fat3d\r\nDiscord: fat3d\r\nCtrl+Shift+F8 pauses inputs.","About SoulAnchor"); });
                button.AutoSize=false; button.Size=new Size(S(175),S(48)); button.Margin=new Padding(0,0,0,S(14)); nav.Controls.Add(button);
            }
            layout.Dock=DockStyle.Fill; layout.Padding=new Padding(S(20),S(20),S(20),S(12)); layout.ColumnCount=1; layout.RowCount=6; layout.BackColor=Color.Transparent;
            layout.RowStyles.Add(new RowStyle(SizeType.Absolute,S(48)));
            layout.RowStyles.Add(new RowStyle(SizeType.Absolute,S(28)));
            layout.RowStyles.Add(new RowStyle(SizeType.Absolute,S(40)));
            layout.RowStyles.Add(new RowStyle(SizeType.Absolute,S(108)));
            layout.RowStyles.Add(new RowStyle(SizeType.Percent,100));
            layout.RowStyles.Add(new RowStyle(SizeType.Absolute,S(90)));
            body.Controls.Add(layout); layout.BringToFront();
            var heading=new Panel { Dock=DockStyle.Fill, BackColor=Color.Transparent };
            heading.Controls.Add(new Label { Text="ROBLOX INSTANCES", Font=UiFont(17,FontStyle.Bold), AutoSize=true, Location=new Point(0,S(10)) });
            var refresh=MakeButton("REFRESH INSTANCES",delegate { Discover(); }); refresh.Dock=DockStyle.Right; heading.Controls.Add(refresh); layout.Controls.Add(heading,0,0);
            summary.Dock=DockStyle.Fill; summary.ForeColor=Accent; layout.Controls.Add(summary,0,1);
            var actions=new FlowLayoutPanel { Dock=DockStyle.Fill, WrapContents=false, AutoScroll=true, BackColor=Color.Transparent };
            actions.Controls.Add(MakeButton("Enable all",delegate { SetAll(true); })); actions.Controls.Add(MakeButton("Disable all",delegate { SetAll(false); }));
            actions.Controls.Add(MakeButton("Test enabled",async delegate { if (!busy) await Cycle(true); })); layout.Controls.Add(actions,0,2);
            var settings=new RoguePanel { Dock=DockStyle.Fill, Padding=new Padding(S(18),S(14),S(18),S(10)) };
            settings.Controls.Add(new Label { Text="ANTI-AFK SETTINGS", AutoSize=true, Location=new Point(S(18),S(12)), Font=UiFont(11,FontStyle.Bold) });
            settings.Controls.Add(new Label { Text="Jump (Space)   |   Interval (minutes)", AutoSize=true, Location=new Point(S(18),S(44)) });
            minutes.Minimum=1; minutes.Maximum=15; minutes.Value=8; minutes.Size=new Size(S(65),S(30)); minutes.Location=new Point(S(310),S(40)); minutes.BackColor=Color.FromArgb(242,214,173); minutes.ForeColor=Color.FromArgb(45,37,27);
            minutes.ValueChanged += delegate { foreach (var i in instances.Values) if (i.Enabled) i.Due=DateTime.UtcNow; SaveSettings(); }; settings.Controls.Add(minutes);
            auto.Text="Enable new instances"; auto.AutoSize=true; auto.Location=new Point(S(18),S(74)); settings.Controls.Add(auto); auto.CheckedChanged += delegate { SaveSettings(); };
            start.Text="START"; Style(start); start.AutoSize=false; start.Size=new Size(S(142),S(38)); start.Anchor=AnchorStyles.Top|AnchorStyles.Right;
            var footer=new FlowLayoutPanel { Dock=DockStyle.Right, Width=S(310), Padding=new Padding(S(8),S(30),0,0), BackColor=Color.Transparent, WrapContents=false };
            start.Click += delegate { SetRunning(!running); }; footer.Controls.Add(start);
            var stop=MakeButton("STOP",delegate { SetRunning(false); }); stop.AutoSize=false; stop.Size=new Size(S(142),S(38)); footer.Controls.Add(stop); settings.Controls.Add(footer);
            layout.Controls.Add(settings,0,3);
            grid.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing; grid.ColumnHeadersHeight = S(40);
            grid.Dock = DockStyle.Fill; grid.BackgroundColor = Panel; grid.BorderStyle = BorderStyle.FixedSingle;
            grid.AllowUserToAddRows = false; grid.AllowUserToDeleteRows = false; grid.RowHeadersVisible = false; grid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            grid.EnableHeadersVisualStyles = false; grid.ColumnHeadersDefaultCellStyle.BackColor = Panel; grid.ColumnHeadersDefaultCellStyle.ForeColor = TextColor; grid.ColumnHeadersDefaultCellStyle.Font = UiFont(10, FontStyle.Bold);
            grid.DefaultCellStyle.BackColor = Bg; grid.DefaultCellStyle.ForeColor = TextColor; grid.DefaultCellStyle.SelectionBackColor = Color.FromArgb(111, 100, 66);
            grid.DefaultCellStyle.SelectionForeColor = TextColor; grid.GridColor = Color.FromArgb(119, 101, 70); grid.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(44, 35, 25); grid.CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal; grid.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.None; grid.RowTemplate.Height = S(48); grid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            grid.Columns.Add(new DataGridViewCheckBoxColumn { Name = "Enabled", HeaderText = "On", FillWeight = 35 });
            foreach (string s in new string[] { "Window", "PID", "Status", "Last input", "Next attempt" }) grid.Columns.Add(new DataGridViewTextBoxColumn { Name = s, HeaderText = s, ReadOnly = true, FillWeight = s == "Window" ? 170 : 90 });
            foreach (DataGridViewColumn c in grid.Columns) c.SortMode = DataGridViewColumnSortMode.NotSortable;
            grid.CellPainting += delegate(object sender, DataGridViewCellPaintingEventArgs e) {
                if (e.RowIndex < 0 || e.ColumnIndex != 0) return;
                e.PaintBackground(e.ClipBounds, true);
                bool enabled = Convert.ToBoolean(e.Value);
                int w=S(44), h=S(20), x=e.CellBounds.X+(e.CellBounds.Width-w)/2, y=e.CellBounds.Y+(e.CellBounds.Height-h)/2;
                using (var fill=new SolidBrush(enabled ? Color.FromArgb(151,56,39) : Color.FromArgb(59,57,52))) e.Graphics.FillRectangle(fill,x,y,w,h);
                using (var border=new Pen(Accent,2)) e.Graphics.DrawRectangle(border,x,y,w,h);
                using (var knob=new SolidBrush(Color.FromArgb(242,214,173))) e.Graphics.FillRectangle(knob,enabled ? x+w-S(17) : x+S(3),y+S(3),S(14),h-S(6));
                e.Handled=true;
            };
            grid.CurrentCellDirtyStateChanged += delegate { if (grid.IsCurrentCellDirty) grid.CommitEdit(DataGridViewDataErrorContexts.Commit); };
            grid.CellValueChanged += delegate(object sender, DataGridViewCellEventArgs e) {
                if (e.RowIndex < 0 || e.ColumnIndex != 0) return;
                var i = grid.Rows[e.RowIndex].Tag as Instance;
                if (i != null) { i.Enabled = Convert.ToBoolean(i.Row.Cells[0].Value); i.Due = DateTime.UtcNow; i.Status = i.Enabled ? "Ready" : "Disabled"; }
            };
            layout.Controls.Add(grid, 0, 4);
            log.Dock = DockStyle.Fill; log.Multiline = true; log.ReadOnly = true; log.ScrollBars = ScrollBars.Vertical; log.BackColor = Panel; log.ForeColor = TextColor; log.BorderStyle = BorderStyle.FixedSingle; log.Font = new Font("Consolas", 9F * 96F / 72F * uiScale, FontStyle.Regular, GraphicsUnit.Pixel); layout.Controls.Add(log, 0, 5);
            tray.Icon = Icon; tray.Text = "SoulAnchor v" + AppVersion + " - Paused";
            trayMenu.Items.Add("Open SoulAnchor", null, delegate { RestoreFromTray(); });
            trayMenu.Items.Add("Pause inputs", null, delegate { SetRunning(false); });
            trayMenu.Items.Add("Exit", null, delegate { Close(); });
            tray.ContextMenuStrip = trayMenu; tray.DoubleClick += delegate { RestoreFromTray(); };
            Resize += delegate { if (WindowState == FormWindowState.Minimized && minimizeToTray && running) HideToTray(); };
            tips.SetToolTip(minutes, "Minutes between inputs for each enabled Roblox instance.");
            tips.SetToolTip(auto, "Automatically enable newly detected Roblox windows.");
            tips.SetToolTip(start, "Start or pause inputs for enabled instances. Ctrl+Shift+F8 also pauses.");
            tips.SetToolTip(minimize, "Minimize the window. The tray setting applies while inputs are running.");
            tips.SetToolTip(grid, "Use the red/cream toggle to enable or disable each Roblox instance. PID identifies its Windows process.");
            LoadSettings(); loadingSettings = false;
            Shown += delegate {
                if (showStartupInfo) MessageBox.Show(this,
                    "SoulAnchor briefly focuses each enabled Roblox window and taps Space. Close in-game chat first.\r\n\r\nWindows accepting input does not confirm that Roblox received it. Keep Windows awake and unlocked. Ctrl+Shift+F8 pauses.\r\n\r\nYou can adjust the PC idle requirement and show or hide the debug panel in Settings.",
                    "SoulAnchor - Before you start", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Discover(); if (!Native.RegisterHotKey(Handle, 1, 0x4006, 0x77)) WriteLog("Pause hotkey unavailable; use the Pause button."); timer.Start(); };
            timer.Interval = 1000; timer.Tick += async delegate {
                if (busy || closing) return;
                if (++ticks % 5 == 0) Discover();
                RefreshRows();
                if (running) await Cycle(false);
            };
            FormClosing += delegate(object sender, FormClosingEventArgs e) {
                if (busy) { e.Cancel = true; SetRunning(false); WriteLog("Finishing the current tap. Close again in a moment."); return; }
                SaveSettings(); closing = true; running = false; timer.Stop(); Native.UnregisterHotKey(Handle, 1);
            };
            FormClosed += delegate { timer.Dispose(); tray.Visible = false; tray.Dispose(); trayMenu.Dispose(); tips.Dispose(); if (Icon != null) Icon.Dispose(); };
            WriteLog("Ready. Join your games, enable their rows, then press Start. Test enabled sends a tap immediately.");
        }
        protected override void WndProc(ref Message m) { if (m.Msg == 0x312 && m.WParam.ToInt32() == 1) SetRunning(false); base.WndProc(ref m); }
        void Style(Button b) { b.AutoSize = true; b.Height = S(34); b.FlatStyle = FlatStyle.Flat; b.FlatAppearance.BorderSize = 2; b.FlatAppearance.BorderColor = Color.FromArgb(151, 118, 75); b.BackColor = Color.FromArgb(242, 214, 173); b.ForeColor = Color.FromArgb(45, 37, 27); b.FlatAppearance.MouseOverBackColor = Color.FromArgb(255, 232, 195); b.FlatAppearance.MouseDownBackColor = Color.FromArgb(205, 175, 132); b.Font = UiFont(10, FontStyle.Bold); b.UseVisualStyleBackColor = false; b.Padding = new Padding(S(10), S(3), S(10), S(3)); b.Margin = new Padding(0, 0, S(8), 0); }
        Button MakeButton(string text, EventHandler click) { var b = new RogueButton { Text = text }; Style(b); b.Click += click;
            string help = text == "Test enabled" ? "Immediately send a Space tap to enabled instances, bypassing the interval and PC idle wait."
                : text == "Enable all" ? "Enable every detected Roblox instance."
                : text == "Disable all" ? "Disable every detected Roblox instance."
                : text == "REFRESH INSTANCES" ? "Rescan open Roblox windows now. The list also refreshes automatically."
                : text == "STOP" ? "Pause automatic inputs."
                : text == "SETTINGS" ? "Adjust and save SoulAnchor preferences."
                : text == "ABOUT" ? "View version and creator information."
                : text == "\u00d7" ? "Close SoulAnchor and stop inputs." : "";
            if (help.Length > 0) tips.SetToolTip(b, help);
            return b; }
        void ShowSettings() {
            if (busy) { WriteLog("Wait for the current input batch to finish, then open Settings."); return; }
            timer.Stop();
            try {
                using (var dialog = new Form()) {
                    dialog.Text = "SoulAnchor Settings"; dialog.AutoScaleMode = AutoScaleMode.None;
                    dialog.ClientSize = new Size(S(450), S(345)); dialog.FormBorderStyle = FormBorderStyle.FixedDialog;
                    dialog.MaximizeBox = false; dialog.MinimizeBox = false; dialog.ShowInTaskbar = false;
                    dialog.StartPosition = FormStartPosition.CenterParent; dialog.BackColor = Bg; dialog.ForeColor = TextColor; dialog.Font = Font;
                    var wait = new CheckBox { Text = "Wait for PC idle before inputs", Checked = waitForIdle, AutoSize = true, Location = new Point(S(24), S(24)) };
                    var caption = new Label { Text = "PC idle time (seconds)", AutoSize = true, Location = new Point(S(24), S(72)) };
                    var delay = new NumericUpDown { Minimum = 1, Maximum = 3600, Value = idleSeconds, Width = S(95), Location = new Point(S(290), S(68)), BackColor = Color.FromArgb(242, 214, 173), ForeColor = Color.FromArgb(45, 37, 27), Enabled = wait.Checked };
                    wait.CheckedChanged += delegate { delay.Enabled = wait.Checked; };
                    var debug = new CheckBox { Text = "Show debug panel", Checked = showDebug, AutoSize = true, Location = new Point(S(24), S(121)) };
                    var startupInfo = new CheckBox { Text = "Show startup info popup", Checked = showStartupInfo, AutoSize = true, Location = new Point(S(24), S(161)) };
                    var trayOption = new CheckBox { Text = "Minimize to tray while running", Checked = minimizeToTray, AutoSize = true, Location = new Point(S(24), S(201)) };
                    tips.SetToolTip(wait, "Wait until you have stopped using the PC before sending automatic inputs. Test enabled bypasses this wait.");
                    tips.SetToolTip(delay, "How many seconds the PC must be idle before automatic inputs can begin.");
                    tips.SetToolTip(debug, "Show or hide the diagnostic log at the bottom of the window.");
                    tips.SetToolTip(startupInfo, "Show the information notice when SoulAnchor starts.");
                    tips.SetToolTip(trayOption, "While running, minimizing hides SoulAnchor in the notification area. Double-click its scroom icon to restore it.");
                    var save = new RogueButton { Text = "Apply", DialogResult = DialogResult.OK, Location = new Point(S(235), S(283)) }; Style(save);
                    var cancel = new RogueButton { Text = "Cancel", DialogResult = DialogResult.Cancel, Location = new Point(S(330), S(283)) }; Style(cancel);
                    dialog.Controls.AddRange(new Control[] { wait, caption, delay, debug, startupInfo, trayOption, save, cancel });
                    dialog.AcceptButton = save; dialog.CancelButton = cancel;
                    if (dialog.ShowDialog(this) == DialogResult.OK) {
                        waitForIdle = wait.Checked; idleSeconds = (int)delay.Value; showDebug = debug.Checked; showStartupInfo = startupInfo.Checked; minimizeToTray = trayOption.Checked;
                        layout.SuspendLayout(); log.Visible = showDebug;
                        layout.RowStyles[5].Height = showDebug ? S(90) : 0;
                        layout.ResumeLayout(true);
                        SaveSettings();
                        WriteLog("Settings applied. Idle requirement: " + (waitForIdle ? idleSeconds + " seconds" : "off") + ".");
                    }
                }
            } finally { if (!closing) timer.Start(); }
        }
        void HideToTray() {
            tray.Visible = true; ShowInTaskbar = false; Hide();
        }
        void RestoreFromTray() {
            ShowInTaskbar = true; Show(); WindowState = FormWindowState.Normal; Activate(); tray.Visible = false;
        }
        void LoadSettings() {
            try {
                if (!System.IO.File.Exists(settingsPath)) return;
                foreach (string line in System.IO.File.ReadAllLines(settingsPath)) {
                    string[] pair = line.Split(new char[] { '=' }, 2);
                    if (pair.Length != 2) continue;
                    string key = pair[0].Trim(), value = pair[1].Trim();
                    int number; bool flag;
                    if (key == "IntervalMinutes" && int.TryParse(value, out number) && number >= 1 && number <= 15) minutes.Value = number;
                    else if (key == "IdleSeconds" && int.TryParse(value, out number) && number >= 1 && number <= 3600) idleSeconds = number;
                    else if (key == "WaitForIdle" && bool.TryParse(value, out flag)) waitForIdle = flag;
                    else if (key == "MinimizeToTray" && bool.TryParse(value, out flag)) minimizeToTray = flag;
                    else if (key == "ShowStartupInfo" && bool.TryParse(value, out flag)) showStartupInfo = flag;
                    else if (key == "ShowDebug" && bool.TryParse(value, out flag)) showDebug = flag;
                    else if (key == "EnableNewInstances" && bool.TryParse(value, out flag)) auto.Checked = flag;
                }
                WriteLog("Saved preferences loaded.");
            } catch (Exception ex) { WriteLog("Could not load preferences; using defaults where needed: " + ex.Message); }
            finally {
                log.Visible = showDebug;
                layout.RowStyles[5].Height = showDebug ? S(90) : 0;
            }
        }
        void SaveSettings() {
            if (loadingSettings) return;
            string temporary = settingsPath + ".tmp";
            try {
                System.IO.Directory.CreateDirectory(System.IO.Path.GetDirectoryName(settingsPath));
                System.IO.File.WriteAllLines(temporary, new string[] {
                    "IntervalMinutes=" + (int)minutes.Value,
                    "WaitForIdle=" + waitForIdle,
                    "IdleSeconds=" + idleSeconds,
                    "ShowDebug=" + showDebug,
                    "ShowStartupInfo=" + showStartupInfo,
                    "MinimizeToTray=" + minimizeToTray,
                    "EnableNewInstances=" + auto.Checked
                });
                if (System.IO.File.Exists(settingsPath)) System.IO.File.Replace(temporary, settingsPath, null);
                else System.IO.File.Move(temporary, settingsPath);
            } catch (Exception ex) { WriteLog("Could not save preferences: " + ex.Message); }
        }
        void SetRunning(bool value) { running = value; start.Text = value ? "PAUSE" : "START"; start.BackColor = value ? Color.FromArgb(198, 181, 132) : Color.FromArgb(242, 214, 173); tray.Text = "SoulAnchor v" + AppVersion + (value ? " - Running" : " - Paused"); WriteLog(value ? "Started." : "Paused."); RefreshRows(); }
        void SetAll(bool value) { foreach (var i in instances.Values) i.Row.Cells[0].Value = value; }
        void WriteLog(string text) { if (closing) return; if (log.TextLength > 22000) log.Text = log.Text.Substring(log.TextLength - 12000); log.AppendText(DateTime.Now.ToString("HH:mm:ss") + "  " + text + Environment.NewLine); }
        void Discover() {
            var found = new HashSet<string>();
            Native.EnumWindows(delegate(IntPtr hwnd, IntPtr unused) {
                if (!Native.IsWindowVisible(hwnd)) return true;
                uint pid; Native.GetWindowThreadProcessId(hwnd, out pid);
                try {
                    using (var p = Process.GetProcessById((int)pid)) {
                        if (!string.Equals(p.ProcessName, "RobloxPlayerBeta", StringComparison.OrdinalIgnoreCase) && !string.Equals(p.ProcessName, "RobloxPlayer", StringComparison.OrdinalIgnoreCase)) return true;
                        if (p.MainWindowHandle != hwnd) return true;
                        string identity = pid + ":" + p.StartTime.ToUniversalTime().Ticks + ":" + hwnd.ToInt64();
                        found.Add(identity);
                        var title = new StringBuilder(512); Native.GetWindowText(hwnd, title, title.Capacity);
                        Instance i;
                        if (!instances.TryGetValue(identity, out i)) {
                            i = new Instance { Hwnd = hwnd, Pid = (int)pid, Identity = identity, Enabled = auto.Checked, Status = auto.Checked ? "Ready" : "Disabled" };
                            int row = grid.Rows.Add(i.Enabled, title.ToString(), pid, i.Status, i.Last, "-");
                            i.Row = grid.Rows[row]; i.Row.Tag = i; instances.Add(identity, i); WriteLog("Detected Roblox PID " + pid + ".");
                        }
                        i.Title = title.ToString();
                    }
                } catch (Exception ex) { if (!(ex is ArgumentException || ex is InvalidOperationException || ex is System.ComponentModel.Win32Exception)) WriteLog("Detection: " + ex.Message); }
                return true;
            }, IntPtr.Zero);
            foreach (var key in instances.Keys.Where(k => !found.Contains(k)).ToArray()) { grid.Rows.Remove(instances[key].Row); instances.Remove(key); }
            RefreshRows();
        }
        void RefreshRows() {
            summary.Text = (running ? "Running" : "Paused") + "  |  " + instances.Count + " instances  |  " + instances.Values.Count(i => i.Enabled) + " enabled";
            foreach (var i in instances.Values) {
                i.Row.Cells[1].Value = i.Title;
                i.Row.Cells[3].Value = i.Status; i.Row.Cells[4].Value = i.Last;
                double seconds = Math.Max(0, (i.Due - DateTime.UtcNow).TotalSeconds);
                i.Row.Cells[5].Value = !i.Enabled || !running ? "-" : seconds == 0 ? "Due" : TimeSpan.FromSeconds(seconds).ToString(@"mm\:ss");
            }
        }
        async Task Cycle(bool test) {
            if (busy || closing) return;
            var targets = instances.Values.Where(i => i.Enabled && (test || i.Due <= DateTime.UtcNow)).ToArray();
            if (targets.Length == 0) return;
            if (!test && waitForIdle && Native.IdleSeconds() < idleSeconds) { foreach (var i in targets) i.Status = "Waiting for PC idle"; RefreshRows(); return; }
            if (Native.ModifiersHeld()) { foreach (var i in targets) i.Status = "Waiting for keys up"; RefreshRows(); return; }
            busy = true;
            IntPtr previous = Native.GetForegroundWindow(), last = IntPtr.Zero;
            try {
                foreach (var i in targets) {
                    if (closing || (!test && !running)) break;
                    if (!i.Enabled || !Native.IsWindow(i.Hwnd)) continue;
                    uint pid; Native.GetWindowThreadProcessId(i.Hwnd, out pid);
                    if (pid != i.Pid) continue;
                    bool minimized = Native.IsIconic(i.Hwnd);
                    bool keyDown = false;
                    try {
                        if (minimized) { Native.ShowWindowAsync(i.Hwnd, 9); await Task.Delay(200); }
                        if (closing || (!test && !running)) break;
                        Native.SetForegroundWindow(i.Hwnd);
                        await Task.Delay(800);
                        if (closing || (!test && !running)) break;
                        if (Native.GetForegroundWindow() != i.Hwnd) { i.Status = "Focus blocked"; i.Due = DateTime.UtcNow.AddSeconds(30); WriteLog("PID " + i.Pid + ": Windows blocked focus; no input sent."); continue; }
                        last = i.Hwnd;
                        if (Native.ModifiersHeld()) { i.Status = "Waiting for keys up"; i.Due = DateTime.UtcNow.AddSeconds(10); continue; }
                        keyDown = Native.Space(false);
                        if (!keyDown) { i.Status = "Input blocked"; i.Due = DateTime.UtcNow.AddSeconds(30); WriteLog("PID " + i.Pid + ": input rejected by Windows."); continue; }
                        await Task.Delay(350);
                        bool stillFocused = Native.GetForegroundWindow() == i.Hwnd;
                        bool released = Native.Space(true); keyDown = !released;
                        if (!released) { i.Status = "Key release failed"; running = false; start.Text = "Start"; WriteLog("Paused: Space release failed. Press and release Space manually."); break; }
                        if (!stillFocused) { i.Status = "Focus changed; retry due"; i.Due = DateTime.UtcNow.AddSeconds(30); WriteLog("PID " + i.Pid + ": focus changed during tap; batch stopped."); break; }
                        i.Status = "Input sent"; i.Last = DateTime.Now.ToString("HH:mm:ss"); i.Due = DateTime.UtcNow.AddMinutes((double)minutes.Value);
                        WriteLog("PID " + i.Pid + ": scan-code Space held 350 ms; verify in-game with Test enabled.");
                    } finally {
                        if (keyDown) Native.Space(true);
                        if (minimized && Native.IsWindow(i.Hwnd)) Native.ShowWindowAsync(i.Hwnd, 6);
                    }
                    if (closing) break;
                    await Task.Delay(250);
                    // A user changing focus interrupts the batch rather than dragging focus back.
                    IntPtr current = Native.GetForegroundWindow();
                    if (!minimized && current != i.Hwnd) { WriteLog("Batch stopped after focus changed."); break; }
                }
            } catch (Exception ex) { WriteLog("Attempt failed: " + ex.Message); }
            finally {
                if (!closing && Native.IsWindow(previous) && (Native.GetForegroundWindow() == last || Native.GetForegroundWindow() == IntPtr.Zero)) Native.SetForegroundWindow(previous);
                busy = false; if (!closing) RefreshRows();
            }
        }
    }
}
