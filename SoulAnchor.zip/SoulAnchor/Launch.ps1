$ErrorActionPreference = 'Stop'
try {
    Add-Type -AssemblyName System.Windows.Forms
    Add-Type -AssemblyName System.Drawing
    $source = Get-Content -LiteralPath (Join-Path $PSScriptRoot 'Source\SoulAnchor.cs') -Raw -Encoding UTF8
    Add-Type -TypeDefinition $source -ReferencedAssemblies System,System.Windows.Forms,System.Drawing,System.Core
    [SoulAnchor.Program]::Run()
} catch {
    Write-Host ('Unable to start SoulAnchor: ' + $_.Exception.Message) -ForegroundColor Red
    exit 1
}
